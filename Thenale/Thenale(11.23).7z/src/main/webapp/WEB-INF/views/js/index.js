/**
 * 
 */
 	function joinform() {
		location.href="memberjoin";
	}